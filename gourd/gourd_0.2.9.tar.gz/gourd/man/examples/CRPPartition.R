CRPPartition(nItems=5, concentration=1.5, discount=0.1)
