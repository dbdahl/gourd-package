CenteredPartition(anchor=c(1,1,1,2,2), shrinkage=3,
                  baseline=CRPPartition(nItems=5, concentration=1.5, discount=0.1))

CenteredPartition(anchor=c(1,1,1,2,2), shrinkage=3,
                  baseline=UniformPartition(nItems=5))
