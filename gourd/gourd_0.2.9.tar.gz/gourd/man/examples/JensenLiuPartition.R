JensenLiuPartition(concentration=0.5, permutation=c(1,5,4,2,3))
