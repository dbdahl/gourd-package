scale <- 0.1
LocationScalePartition(anchor=c(1,1,1,2,2), shrinkage=1/scale,
                       concentration=0.6, permutation=c(1,5,4,2,3))
