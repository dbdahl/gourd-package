# Automatically regenerated. Do not edit.

# .Call(.all, all)
# .Call(.data__data_encode, data, missing_items)
# .Call(.fit, n_updates, data, state, hyperparameters, monitor, partition_distribution, mcmc_tuning, permutation_bucket, shrinkage_bucket, grit_bucket, rngs)
# .Call(.fit_dependent, model_id, all, anchor_anchor, anchor_shrinkage, anchor_shrinkage_reference, anchor_concentration, baseline_concentration, hyperparameters, unit_mcmc_tuning, global_mcmc_tuning, validation_data)
# .Call(.hyperparameters__hyperparameters_encode, hyperparameters)
# .Call(.log_likelihood, state, data)
# .Call(.log_likelihood_contributions, state, data)
# .Call(.log_likelihood_contributions_of_missing, state, data)
# .Call(.log_likelihood_of, state, data, items)
# .Call(.monitor__monitor_new)
# .Call(.monitor__monitor_rate, monitor)
# .Call(.monitor__monitor_reset, monitor)
# .Call(.new_CppParameters, anchor, rate, baseline, use_vi, a)
# .Call(.new_CrpParameters, n_items, concentration, discount)
# .Call(.new_FixedPartitionParameters, anchor)
# .Call(.new_JlpParameters, concentration, permutation)
# .Call(.new_LspParameters, anchor, shrinkage, concentration, permutation)
# .Call(.new_SpParameters, anchor, shrinkage, permutation, grit, baseline, shortcut)
# .Call(.new_UpParameters, n_items)
# .Call(.prPartition, partition, prior)
# .Call(.rand_index_for_r, labels_truth, labels_estimate, a)
# .Call(.rngs_new)
# .Call(.samplePartition, n_samples, n_items, prior, randomize_permutation, randomize_shrinkage, max, shape1, shape2, n_cores)
# .Call(.sample_multivariate_normal, n_samples, mean, precision)
# .Call(.state__state_decode, state)
# .Call(.state__state_encode, state)
# .Call(.summarize_prior_on_shrinkage_and_grit, anchor, shrinkage_shape, shrinkage_rate, grit_shape1, grit_shape2, concentration, shrinkage_n, grit_n, n_mc_samples, domain_specification, n_cores)

#' @keywords internal
#' @usage NULL
#' @useDynLib gourd, .registration = TRUE
"_PACKAGE"

.Kall <- function(...) {
  x <- .Call(...)
  if (inherits(x, "error")) stop(x) else x
}